package com.example.mgj.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mgj.R;
import com.example.mgj.model.Tank;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.google.firebase.firestore.FirebaseFirestore;

public class TankAdapter extends FirestoreRecyclerAdapter<Tank, TankAdapter.ViewHolder> {
    FirebaseFirestore fStore;
    Activity activity;
    public TankAdapter(@NonNull FirestoreRecyclerOptions<Tank> options, Activity activity){//este apartado ayuda para los fragments OJO para tenerlos con getactivity
        super(options);
        fStore = FirebaseFirestore.getInstance();
        this.activity = activity;
    }



    @Override
    protected void onBindViewHolder(@NonNull ViewHolder viewHolder, int i, @NonNull Tank Tank) {
        // Configura el nombre del tanque
        viewHolder.name.setText(Tank.getName());
        // Obtén el nivel actual del tanque como String
        // Obtén el nivel actual del tanque
        int currentLevel = Tank.getCurrent_level(); // Asegúrate de tener un mé

        // Calcula el porcentaje de capacidad
        int maxCapacity = 22500;
        int capacityPercentage = (int) ((currentLevel / (double) maxCapacity) * 100);

        // Muestra los valores en los TextViews
        viewHolder.current_level.setText(String.format("%d", currentLevel)); // Muestra el nivel actual
        viewHolder.capacity.setText(String.format("%d%%", capacityPercentage)); // Muestra el porcentaje de capacidad
    }
    
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclertankfragment, parent, false);
        return new ViewHolder(v);
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView name, capacity, current_level;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name= itemView.findViewById(R.id.tankTitle);
            capacity= itemView.findViewById(R.id.tankProcentaje);
            current_level= itemView.findViewById(R.id.tankCapacity);
        }
    }
}
